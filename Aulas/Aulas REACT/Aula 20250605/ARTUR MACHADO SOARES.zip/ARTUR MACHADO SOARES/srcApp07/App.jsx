import React from 'react';
import Whatsapp from './componentes/WhatsApp';


function App() {
   return(

    <>
    <Whatsapp />
    </>
    
  )
}

export default App
