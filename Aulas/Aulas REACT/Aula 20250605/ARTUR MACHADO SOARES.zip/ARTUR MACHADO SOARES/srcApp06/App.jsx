import React from 'react';
import Contadores from './componentes/Contadores'
import Ranking from './componentes/Ranking/Ranking';

function App() {
  return (
    <>
    {/* <Contadores /> */}
    <Ranking/>
    </>
  );
}

export default App;